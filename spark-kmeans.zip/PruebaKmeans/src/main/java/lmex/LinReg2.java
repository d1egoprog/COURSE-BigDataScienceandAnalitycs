package lmex;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
//$example on$
import java.util.Arrays;
import java.util.List;

import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.ml.regression.GeneralizedLinearRegression;
import org.apache.spark.ml.regression.GeneralizedLinearRegressionModel;
import org.apache.spark.ml.regression.GeneralizedLinearRegressionTrainingSummary;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.ml.regression.LinearRegressionTrainingSummary;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
//$example off$
import org.apache.spark.sql.SparkSession;
import org.json.JSONArray;
import org.json.JSONObject;

/**
* An example demonstrating generalized linear regression.
* Run with
* <pre>
* bin/run-example ml.JavaGeneralizedLinearRegressionExample
* </pre>
*/

public class LinReg2 {

	public static void main(String[] args) {
		
		 SparkSession spark = SparkSession
		   .builder()
		   .appName("LinRegG")
		   .config("spark.master", "local") //add
		   .getOrCreate();
		
		 
		 String prb;
		 JSONObject jos = new JSONObject();
		 JSONArray jas;
		 // $example on$
		 // Load training data
		 Dataset<Row> dataset = spark.read().format("libsvm")
		   .load("data/Cadena_Productiva_Cafe_prod_a_lr.txt");

		LinearRegression lr = new LinearRegression()
				  .setMaxIter(11)
				  .setRegParam(0.3)
				  .setElasticNetParam(0.8);
		
		// Fit the model.
		LinearRegressionModel lrModel = lr.fit(dataset);
		prb=lrModel.coefficients().toString();
		jas= new JSONArray(prb);
		System.out.println("Coefficients jsa: "+jas);
				// Print the coefficients and intercept for linear regression.
		System.out.println("Coefficients: "
				  + lrModel.coefficients() + " Intercept: " + lrModel.intercept());

				// Summarize the model over the training set and print out some metrics.
		LinearRegressionTrainingSummary trainingSummary = lrModel.summary();
		System.out.println("numIterations: " + trainingSummary.totalIterations());
		System.out.println("objectiveHistory: " + Vectors.dense(trainingSummary.objectiveHistory()));
		trainingSummary.residuals().show();
		System.out.println("RMSE: " + trainingSummary.rootMeanSquaredError());
		System.out.println("r2: " + trainingSummary.r2());
		
		//add to Json Object
		List<Double> prb2=trainingSummary.residuals().as(Encoders.DOUBLE()).collectAsList();
		System.out.println("residuales prb: "+ prb2);
		jos.put("coeficientes", jas);
		jos.put("intercepto",lrModel.intercept());
		jos.put("objectiveHistory",Vectors.dense(trainingSummary.objectiveHistory()).toArray());
		jos.put("residuals",prb2);
		jos.put("RMSE",trainingSummary.rootMeanSquaredError());
		jos.put("r2", trainingSummary.r2());
		
		//crear json
		try {
			File fl= new File("data/result/lr/linRegResult.json");
			if(fl.exists()){
				
				fl.delete();
			}
			System.out.println("actual path "+fl.getCanonicalPath());
			FileWriter flwr =new FileWriter(fl,false);
			
			flwr.write(jos.toString(4));
			flwr.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error al guardar");
			e.printStackTrace();
		}
		
		//crear archivos con coeficientes, intercepto y r2
		//coeficientes
		try {
			File fl2= new File("data/result/lr/coeficients.csv");
			if(fl2.exists()){
				
				fl2.delete();
			}
			System.out.println("actual path "+fl2.getCanonicalPath());
			FileWriter flwr =new FileWriter(fl2,false);
			prb=prb.replace("[","");
			prb=prb.replace("]","");
			flwr.write(prb);
			flwr.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error al guardar");
			e.printStackTrace();
		}
		
		//intercept
		try {
			File fl3= new File("data/result/lr/intercept.csv");
			if(fl3.exists()){
				
				fl3.delete();
			}
			System.out.println("actual path "+fl3.getCanonicalPath());
			FileWriter flwr =new FileWriter(fl3,false);
			//prb=prb.replace("[","");
			//prb=prb.replace("]","");
			flwr.write(String.valueOf(lrModel.intercept()));
			flwr.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error al guardar");
			e.printStackTrace();
		}
		
		//r2
				try {
					File fl4= new File("data/result/lr/r2.csv");
					if(fl4.exists()){
						
						fl4.delete();
					}
					System.out.println("actual path "+fl4.getCanonicalPath());
					FileWriter flwr =new FileWriter(fl4,false);
					//prb=prb.replace("[","");
					//prb=prb.replace("]","");
					flwr.write(String.valueOf(trainingSummary.r2()));
					flwr.close();
					
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.out.println("Error al guardar");
					e.printStackTrace();
				}

	}
}