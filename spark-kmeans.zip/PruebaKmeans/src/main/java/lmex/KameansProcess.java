package lmex;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.clustering.KMeans;
import org.apache.spark.mllib.clustering.KMeansModel;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.Vectors;
import org.json.JSONArray;
import org.json.JSONObject;
import org.spark_project.guava.io.Files;



public class KameansProcess {
	
	public static void main(String[] args) {
		
		JSONObject jos = new JSONObject();
		JSONObject jos2 =new JSONObject();
		JSONArray jas = new JSONArray();
		JSONArray jas2 = new JSONArray();
		JSONArray jas3 =new JSONArray();
	    SparkConf conf = new SparkConf()
	    		.setMaster("local")//add
	    		.setAppName("KameansProcess");
	    JavaSparkContext jsc = new JavaSparkContext(conf);

	    // $example on$
	    // Load and parse data
	    String path = "data/Cadena_Productiva_Cafe_prod_a.txt";
	    JavaRDD<String> data = jsc.textFile(path);
	    JavaRDD<Vector> parsedData = data.map(s -> {
	      String[] sarray = s.split(" ");
	      double[] values = new double[sarray.length];
	      for (int i = 0; i < sarray.length; i++) {
	        values[i] = Double.parseDouble(sarray[i]);
	      }
	      return Vectors.dense(values);
	    });
	    parsedData.cache();

	    // Cluster the data into two classes using KMeans
	    int numClusters = 3;
	    int numIterations = 20;
	    KMeansModel clusters = KMeans.train(parsedData.rdd(), numClusters, numIterations);
	    
	    ArrayList<Vector> arrL = new ArrayList<Vector>();
	    System.out.println("Cluster centers:");
	    for (Vector center: clusters.clusterCenters()) {
	      jas.put(center.toArray());
	      arrL.add(center);
	      System.out.println(" " + center);
	    }
	    jos.put("centroids", jas);
	    double cost = clusters.computeCost(parsedData.rdd());
	    System.out.println("Cost: " + cost);
	    jos.put("cost",cost);
	    // Evaluate clustering by computing Within Set Sum of Squared Errors
	    double WSSSE = clusters.computeCost(parsedData.rdd());
	    System.out.println("Within Set Sum of Squared Errors = " + WSSSE);
	    jos.put("WSSSE",WSSSE);
	    
	    //int idca=0;
	    int idc=0;
	    int cont=0;
	    //datos con centroides asignados
	    List<Vector> vectors = parsedData.collect();
	    //ArrayList<Vector> aux=new ArrayList<Vector>();
	    //ArrayList<ArrayList<JSONArray>> arrV= new  ArrayList<ArrayList<JSONArray>>();
	    ArrayList<JSONArray> arrV = new ArrayList<JSONArray>();
	    //crear listas
	    for(Vector v:arrL){
	    	arrV.add(new JSONArray());
	    }
	    //lenar listas
	    for(Vector vector: vectors){
	        
	    	System.out.println("vector size "+vectors.size());
	    	
	    	
	    	//idca=idc;
	    	idc=clusters.predict(vector);
	    	arrV.get(idc).put(vector.toArray());
	    	/*
	    	if(cont==vectors.size()){
	    		jas2.put(vector.toArray());
	    	}
	    	
	        if(idca!=idc||cont==vectors.size()){
	        	
	        	
		        jos2.put("centroidID",idca);
		        jos2.put("centroidData", arrL.get(idca).toArray());
	        	jos2.put("dataVectors",jas2);
	        	jas3.put(jos2);
	        	jos2 = new JSONObject();
	        	jas2= new JSONArray();
	        	
	        	
	        }
	        jas2.put(vector.toArray());
	        cont++;*/
	    	System.out.println("cluster "+clusters.predict(vector) +" "+vector.toString());
	    	
	    }
	    
	    //crear JSONARRAY
	    for(int i=0;i<arrV.size();i++){
	    	jos2 = new JSONObject();
	    	jos2.put("centroidID",i);
	    	jos2.put("centroidData",arrL.get(i).toArray());
	    	jos2.put("dataVectors",arrV.get(i));
	    	jas3.put(jos2);
	    }
	    
	    //jas3.put(jos2);
	    jos.put("kmeansData",jas3);
	    //guardar centroides y constos en json file
	    try {
			File fl= new File("data/result/km/KmeansResult.json");
			if(fl.exists()){
				
				fl.delete();
			}
			System.out.println("actual path "+fl.getCanonicalPath());
			FileWriter flwr =new FileWriter(fl,false);
			
			flwr.write(jos.toString(4));
			flwr.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error al guardar");
			e.printStackTrace();
		}
	    
	    //archivos csv independientes
	    
	    //centroides
	    	String prb;
	    	int idtc=0;
	    	for(Vector ve:arrL){
		  		try {
		  			File fl2= new File("data/result/km/centroide_"+idtc+".csv");
		  			if(fl2.exists()){
		  				
		  				fl2.delete();
		  			}
		  			prb=Arrays.toString(ve.toArray());
		  			System.out.println("actual path "+fl2.getCanonicalPath());
		  			FileWriter flwr =new FileWriter(fl2,false);
		  			prb=prb.replace("[","");
		  			prb=prb.replace("]","");
		  			flwr.write(prb);
		  			flwr.close();
		  			
		  			
		  		} catch (IOException e) {
		  			// TODO Auto-generated catch block
		  			System.out.println("Error al guardar");
		  			e.printStackTrace();
		  		}
		  		idtc++;
	    	}
	    jsc.stop();
	  }
}
