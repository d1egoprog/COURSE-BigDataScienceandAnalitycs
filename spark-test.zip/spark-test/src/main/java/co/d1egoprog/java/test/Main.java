package co.d1egoprog.java.test;

import javax.sql.DataSource;

public class Main {

	public Main() {
		DataSource source = new DataSource("/some/where/data.arff");
		 Instances data = source.getDataSet();
	}
	
	public static void main(String[] args) {
		new Main();
	}
}
